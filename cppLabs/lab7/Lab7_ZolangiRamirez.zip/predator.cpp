#include "predator.h"
using namespace std;

Predator::Predator(string nameIn, double weighIn): Animal(nameIn, weighIn) {};
void Predator::predate(Prey *prey){};
